<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpressdb' );

/** Database username */
define( 'DB_USER', 'wpuser' );

/** Database password */
define( 'DB_PASSWORD', '2200aADSfamilyroyal' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'V<m9:B&8%<B$~EHks!?!_t_OAGr<yeD6RPq~^+r=7aVvkAXejl7f~x;,jUhh}#Op' );
define( 'SECURE_AUTH_KEY',  'hqVF0v%@?/wdOHS(Uo:W4H70veeVDC8M%0A;^ymyv$v5zN5y4n{2W0h?_7Hh+;n%' );
define( 'LOGGED_IN_KEY',    'd:}boE>Wrl6UGaW=DG+ps27DdNQvr]B;FCEk`])#skHkU}}S@%-xbmL]}0>}Kk%D' );
define( 'NONCE_KEY',        'hOJP^Atl5[3hF$+Hog7%3Oc8jd$fbYwjMf,aM91p?IDm0e!Px4`V_4<EBtLc6,:(' );
define( 'AUTH_SALT',        'uBhL^N@oH#HQg^iX^8=90)G{!ya4dEEps#&o>W}0P/=B3R,qZ7+s]=ED-Hluo,IJ' );
define( 'SECURE_AUTH_SALT', 'o-ou_|7wz|sW?YU{=]J}=ELxI:sd`o16zUx404R@DGF`l 0au#x#8fM;Rb_-fvRA' );
define( 'LOGGED_IN_SALT',   'Y1<X)hr7Yzp0)p,hd@/|&*HFin<~iX,UK[^2Th#Q(uTnaHDF2UmzrQV~+{x7T*p~' );
define( 'NONCE_SALT',       'N<;gPO|@;g/Z^Mwk4-)W,m,_d&E][Z-bq},Zto6&-o6@kO[Ho,1{kp2[EVJ&>_A=' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
